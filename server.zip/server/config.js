var config = {
	debug: false,
	database: {
		host: "184.168.115.180",
		user: "i6703111_wp29",
		password: "G.a8SBheHXPykHp62qL66",
		database: "i6703111_wp29",
		charset : "utf8",
		prefix : "wp_"
	},
	cors: {
		origin: '*',
 		optionsSuccessStatus: 200
	}
}

module.exports = config; 